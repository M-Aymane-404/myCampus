package com.mycampus.backend.metier.professeur.notes;

import com.mycampus.backend.dto.professeur.DonneeEntrer.notes.SaisieNoteEntrerDTO;
import com.mycampus.backend.dto.professeur.DonneeSortie.notes.FeuilleNotesSortieDTO;
import com.mycampus.backend.dto.professeur.DonneeSortie.notes.LigneNoteSortieDTO;
import com.mycampus.backend.dto.professeur.DonneeSortie.notes.PublierNotesSortieDTO;
import com.mycampus.backend.dto.professeur.DonneeSortie.notes.StatsNotesSortieDTO;
import com.mycampus.backend.entites.*;
import com.mycampus.backend.enumerations.EtatExamen;
import com.mycampus.backend.exceptions.NotesProfesseurException;
import com.mycampus.backend.repositorys.*;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Transactional
@Service
@RequiredArgsConstructor
public class GestionNotesProfesseurMetierImpl implements GestionNotesProfesseurMetier {
    private final ExamenRepository examenRepo;
    private final ClasseRepository classeRepo;
    private final EtudiantRepository etudiantRepo;
    private final ResultatRepository resultatRepo;
    private final AffectationEnseignementRepository affectationRepo;
  //  private final StockageFichiersService stockage;


    private Examen requireExamen(Long examenId) {
        return examenRepo.findByIdWithMatiere(examenId)
                .orElseThrow(() -> new NotesProfesseurException("Examen introuvable."));
    }

    private void requireOwnership(String ppr, String codeClasse, String codeMatiere) {
        List<AffectationEnseignement> aes = affectationRepo.findActiveByProfClasseMatiere(ppr, codeClasse, codeMatiere);
        if (aes.isEmpty()) throw new NotesProfesseurException("Accès refusé: affectation inexistante/inactive.");
        if (aes.size() > 1) throw new NotesProfesseurException("Contexte ambigu: plusieurs affectations actives. Préciser l'année.");
    }

    private Classe requireClasse(String codeClasse) {
        return classeRepo.findByCodeClasse(codeClasse)
                .orElseThrow(() -> new NotesProfesseurException("Classe introuvable: " + codeClasse));
    }

    private static double round2(double v) { return Math.round(v * 100.0) / 100.0; }

    @Override
    @Transactional(readOnly = true)
    public FeuilleNotesSortieDTO chargerFeuille(String ppr, String codeClasse, Long examenId) {
        Examen examen = requireExamen(examenId);
        String codeMatiere = examen.getMatiere().getCodeMatiere();

        requireOwnership(ppr, codeClasse, codeMatiere);

        Classe classe = requireClasse(codeClasse);

        List<EtudiantFeuilleProjection> etudiants = etudiantRepo.findEtudiantsFeuilleByCodeClasse(codeClasse);
        List<Resultat> resultats = resultatRepo.findAllByExamenId(examenId);

        Map<Long, Resultat> mapRes = resultats.stream()
                .filter(r -> r.getEtudiant() != null)
                .collect(Collectors.toMap(r -> r.getEtudiant().getId(), r -> r, (a, b) -> a));

        List<LigneNoteSortieDTO> lignes = new ArrayList<>();
        List<Double> notes = new ArrayList<>();
        int nbSaisies = 0;

        for (EtudiantFeuilleProjection e : etudiants) {
            Resultat r = mapRes.get(e.getIdEtudiant());

            Double note = (r == null) ? null : r.getNote();
            boolean publiee = (r != null && r.getDatePublication() != null);
            boolean copie = (r != null && r.getCopieEtudiantPath() != null && !r.getCopieEtudiantPath().isBlank());

            if (note != null) {
                nbSaisies++;
                notes.add(note);
            }

            lignes.add(LigneNoteSortieDTO.builder()
                    .idResultat(r == null ? null : r.getId())
                    .idEtudiant(e.getIdEtudiant())
                    .apogee(e.getApogee())
                    .nom(e.getNom())
                    .prenom(e.getPrenom())
                    .note(note)
                    .publiee(publiee)
                    .copieDisponible(copie)
                    .build());
        }

        StatsNotesSortieDTO stats = buildStats(etudiants.size(), nbSaisies, notes);

        return FeuilleNotesSortieDTO.builder()
                .codeClasse(codeClasse)
                .nomClasse(classe.getNom())
                .idExamen(examen.getId())
                .codeMatiere(codeMatiere)
                .nomMatiere(examen.getMatiere().getNom() == null ? "" : examen.getMatiere().getNom())
                .semestre(examen.getSemestre())
                .numeroExamen(examen.getNumeroExamen())
                .typeExamen(examen.getTypeExamen())
                .dateExamen(examen.getDateExamen())
                .duree(examen.getDuree())
                .etat(examen.getEtat())
                .lignes(lignes)
                .stats(stats)
                .build();
    }

    private StatsNotesSortieDTO buildStats(int total, int nbSaisies, List<Double> notes) {
        Double min = null, max = null, moy = null;

        if (!notes.isEmpty()) {
            min = notes.stream().min(Double::compareTo).orElse(null);
            max = notes.stream().max(Double::compareTo).orElse(null);
            moy = notes.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
            moy = round2(moy);
        }

        return StatsNotesSortieDTO.builder()
                .totalEtudiants(total)
                .nbNotesSaisies(nbSaisies)
                .min(min)
                .max(max)
                .moyenne(moy)
                .build();
    }

    @Override
    public LigneNoteSortieDTO autosaveNote(String ppr, String codeClasse, Long examenId, SaisieNoteEntrerDTO dto) {
        if (dto == null || dto.getIdEtudiant() == null) throw new NotesProfesseurException("idEtudiant obligatoire.");
        if (dto.getNote() != null && (dto.getNote() < 0 || dto.getNote() > 20)) throw new NotesProfesseurException("Note doit être entre 0 et 20.");

        Examen examen = requireExamen(examenId);
        String codeMatiere = examen.getMatiere().getCodeMatiere();
        requireOwnership(ppr, codeClasse, codeMatiere);

        if (!etudiantRepo.existsByIdAndClasse_CodeClasse(dto.getIdEtudiant(), codeClasse)) {
            throw new NotesProfesseurException("Étudiant ne fait pas partie de la classe.");
        }

        Resultat resultat = resultatRepo.findByExamen_IdAndEtudiant_Id(examenId, dto.getIdEtudiant())
                .orElseGet(() -> {
                    Resultat r = new Resultat();
                    r.setExamen(examen);
                    Etudiant et = new Etudiant();
                    et.setId(dto.getIdEtudiant());
                    r.setEtudiant(et);
                    return r;
                });

        // draft : ne pas publier
        resultat.setNote(dto.getNote());
        resultat.setDatePublication(null);

        Resultat saved = resultatRepo.save(resultat);

        return LigneNoteSortieDTO.builder()
                .idResultat(saved.getId())
                .idEtudiant(dto.getIdEtudiant())
                .note(saved.getNote())
                .publiee(false)
                .copieDisponible(saved.getCopieEtudiantPath() != null && !saved.getCopieEtudiantPath().isBlank())
                .build();
    }

    @Override
    public int publierNotes(String ppr, String codeClasse, Long examenId) {
        Examen examen = requireExamen(examenId);
        String codeMatiere = examen.getMatiere().getCodeMatiere();
        requireOwnership(ppr, codeClasse, codeMatiere);

        List<Resultat> resultats = resultatRepo.findAllByExamenId(examenId);
        if (resultats.isEmpty()) throw new NotesProfesseurException("Aucun résultat à publier.");

        LocalDateTime now = LocalDateTime.now();
        for (Resultat r : resultats) {
            // publie seulement si une note existe (choix pragmatique)
            if (r.getNote() != null) {
                r.setDatePublication(now);
            }
        }
        resultatRepo.saveAll(resultats);

        examen.setEtat(EtatExamen.CORRIGE);
        examenRepo.save(examen);

        int publies = (int) resultats.stream().filter(r -> r.getDatePublication() != null).count();
        return publies;
    }

   /* @Override
    public LigneNoteSortieDTO deposerCopieEtudiant(String ppr, String codeClasse, Long examenId, Long etudiantId, MultipartFile pdf) {
        Examen examen = requireExamen(examenId);
        String codeMatiere = examen.getMatiere().getCodeMatiere();
        requireOwnership(ppr, codeClasse, codeMatiere);

        if (!etudiantRepo.existsByIdAndClasse_CodeClasse(etudiantId, codeClasse)) {
            throw new NotesProfesseurException("Étudiant ne fait pas partie de la classe.");
        }

        Resultat resultat = resultatRepo.findByExamen_IdAndEtudiant_Id(examenId, etudiantId)
                .orElseGet(() -> {
                    Resultat r = new Resultat();
                    r.setExamen(examen);
                    Etudiant et = new Etudiant();
                    et.setId(etudiantId);
                    r.setEtudiant(et);
                    return r;
                });

        String path = stockage.sauvegarderPdf(pdf, "resultats/copies");
        resultat.setCopieEtudiantPath(path);

        Resultat saved = resultatRepo.save(resultat);

        return LigneNoteSortieDTO.builder()
                .idResultat(saved.getId())
                .idEtudiant(etudiantId)
                .copieDisponible(true)
                .publiee(saved.getDatePublication() != null)
                .note(saved.getNote())
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public Resource telechargerCopieEtudiantProf(String ppr, String codeClasse, Long examenId, Long etudiantId) {
        Examen examen = requireExamen(examenId);
        String codeMatiere = examen.getMatiere().getCodeMatiere();
        requireOwnership(ppr, codeClasse, codeMatiere);

        Resultat r = resultatRepo.findByExamen_IdAndEtudiant_Id(examenId, etudiantId)
                .orElseThrow(() -> new NotesProfesseurException("Aucune copie disponible (résultat introuvable)."));

        if (r.getCopieEtudiantPath() == null || r.getCopieEtudiantPath().isBlank()) {
            throw new NotesProfesseurException("Aucune copie disponible pour cet étudiant.");
        }

        return stockage.chargerCommeResource(r.getCopieEtudiantPath());
    }
}*/
}
