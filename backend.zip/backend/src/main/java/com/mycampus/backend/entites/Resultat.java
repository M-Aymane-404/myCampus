package com.mycampus.backend.entites;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Builder
@AllArgsConstructor
@ToString(exclude = {"examen", "etudiant"})
@EqualsAndHashCode(exclude = {"examen", "etudiant"})
@Table(
        name = "resultat",
        uniqueConstraints = @UniqueConstraint(
                name = "uk_resultat_examen_etudiant",
                columnNames = {"examen_id", "etudiant_id"}
        )
)
public class Resultat {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = true)
    private Double note;
    


    @Column(nullable = true)
    private LocalDateTime datePublication;
    

    
    private String copieEtudiantPath;
    
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "examen_id", nullable = false)
    private Examen examen;
    
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "etudiant_id", nullable = false)
    private Etudiant etudiant;
}
