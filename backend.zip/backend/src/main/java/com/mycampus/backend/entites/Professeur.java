package com.mycampus.backend.entites;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Entity
@PrimaryKeyJoinColumn(name = "utilisateur_id")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@ToString(exclude = {"affectationEnseignements", "departementOuTravail", "departementDirigee", "filiereDirigee"})
@EqualsAndHashCode(callSuper = true, onlyExplicitlyIncluded = true)
public class Professeur extends Utilisateur {
    
    @Column(nullable = false, unique = true)
    private String ppr;
    
    @Column(nullable = false)
    private String specialite;
    
    @Column(nullable = false)
    private String grade;

    private LocalDate dateRecrutement;
    
    private String statut;
    
    @OneToMany(mappedBy = "professeur", fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    private List<AffectationEnseignement> affectationEnseignements;

    @ManyToOne(fetch = FetchType.LAZY)
    private Departement departementOuTravail;

    @OneToOne(mappedBy = "chefDepartement")

    private Departement departementDirigee;

    @OneToOne( mappedBy = "chefFiliere")
    private Filiere filiereDirigee;

}
