/*package com.mycampus.backend.mappers.professeur;

import com.mycampus.backend.dto.professeur.DonneeSortie.notes.LigneNoteSortieDTO;
import com.mycampus.backend.entites.Resultat;

public class NotesProfesseurMapper {

    public static LigneNoteSortieDTO toLigneDTO(EtudiantFeuilleProjection e, Resultat r) {
        return LigneNoteSortieDTO.builder()
                .idResultat(r == null ? null : r.getId())
                .idEtudiant(e.getIdEtudiant())
                .apogee(e.getApogee())
                .nom(e.getNom())
                .prenom(e.getPrenom())
                .note(r == null ? null : r.getNote())
                .publiee(r != null && r.getDatePublication() != null)
                .copieDisponible(r != null
                        && r.getCopieEtudiantPath() != null
                        && !r.getCopieEtudiantPath().isBlank())
                .build();
    }
}
*/